```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import mpl_toolkits
%matplotlib inline

data = pd.read_csv("kc_house_data.csv")
data.head()
data.describe()

data['bedrooms'].value_counts().plot(kind='bar')
plt.title('Number of Bedroom')
plt.xlabel('Bedrooms')
plt.ylabel('Count')
sns.despine()

plt.figure(figsize=(10,10))
sns.jointplot(x=data.lat.values, y=data.long.values, size=10)
plt.ylabel('Longitude', fontsize=12)
plt.xlabel('Latitude', fontsize=12)
plt.show()

plt1 = plt.figure()
sns.despine()

plt.scatter(data.price, data.sqft_living)
plt.title("Price vs Square Feet")
plt.xlabel("Price")
plt.ylabel('Square Feet')
plt.show()

plt.scatter(data.price, data.long)
plt.title("Price vs Location of the area (Longitude)")
plt.xlabel("Price")
plt.ylabel('Longitude')
plt.show()

plt.scatter(data.price, data.lat)
plt.title("Price vs Location of the area (Latitude)")
plt.xlabel("Price")
plt.ylabel('Latitude')
plt.show()

plt.scatter(data.bedrooms, data.price)
plt.title("Bedroom and Price ")
plt.xlabel("Bedrooms")
plt.ylabel("Price")
plt.show()

plt.scatter((data['sqft_living']+data['sqft_basement']), data['price'])
plt.scatter(data.waterfront, data.price)
plt.title("Waterfront vs Price (0= no waterfront)")
plt.xlabel("Waterfront")
plt.ylabel("Price")
plt.show()

train1 = data.drop(['id', 'price'], axis=1)
data.floors.value_counts().plot(kind='bar')
plt.scatter(data.floors, data.price)
plt.scatter(data.condition, data.price)
plt.scatter(data.zipcode, data.price)
plt.title("Which is the pricey location by zipcode?")

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

reg = LinearRegression()
labels = data['price']
conv_dates = [1 if values == 2014 else 0 for values in data.date ]
data['date'] = conv_dates
train1 = data.drop(['id', 'price'], axis=1)
x_train , x_test , y_train , y_test = train_test_split(train1 , labels , test_size = 0.10,random_state =2)
reg.fit(x_train,y_train)
print("Linear Regression Score:", reg.score(x_test,y_test))

from sklearn import ensemble
clf = ensemble.GradientBoostingRegressor(n_estimators = 400, max_depth = 5, min_samples_split = 2,learning_rate = 0.1, loss = 'squared_error')
clf.fit(x_train, y_train)
print("Gradient Boosting Regressor Score:", clf.score(x_test,y_test))

t_sc = np.zeros(clf.n_estimators, dtype=np.float64)
y_pred = reg.predict(x_test)
for i, y_pred in enumerate(clf.staged_predict(x_test)):
    t_sc[i] = np.mean((y_test - y_pred) ** 2)  # Calculate mean squared error
testsc = np.arange((clf.n_estimators)) + 1

plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.plot(testsc, clf.train_score_,'b-', label= 'Set dev train')
plt.plot(testsc, t_sc,'r-', label = 'set dev test')

from sklearn.preprocessing import scale
from sklearn.decomposition import PCA

pca = PCA()
pca.fit_transform(scale(train1))

```

    C:\Users\bhanu\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    C:\Users\bhanu\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_0_1.png)
    



    <Figure size 1000x1000 with 0 Axes>



    
![png](output_0_3.png)
    



    
![png](output_0_4.png)
    



    
![png](output_0_5.png)
    



    
![png](output_0_6.png)
    



    
![png](output_0_7.png)
    



    
![png](output_0_8.png)
    


    Linear Regression Score: 0.7320342760357392
    Gradient Boosting Regressor Score: 0.9195914721810241
    




    array([[-2.64785461e+00, -4.54699955e-02, -3.16665762e-01, ...,
            -7.94687728e-02, -1.03086740e-16,  0.00000000e+00],
           [-2.34485164e-01,  1.68297114e+00, -7.61521725e-01, ...,
             9.81487761e-01, -1.67846012e-15, -0.00000000e+00],
           [-2.57007792e+00, -6.14344122e-01,  3.49292423e-01, ...,
            -1.38570764e-01,  1.24414770e-14,  0.00000000e+00],
           ...,
           [-2.41985641e+00, -1.10027662e+00, -1.46293798e+00, ...,
             9.66785881e-01,  7.60607258e-17, -0.00000000e+00],
           [ 3.32183025e-01, -1.88043103e+00, -1.04412760e+00, ...,
            -3.97449542e-01, -5.35959542e-17,  0.00000000e+00],
           [-2.43180432e+00, -1.08505981e+00, -1.47248379e+00, ...,
             9.53674385e-01,  7.29373160e-17, -0.00000000e+00]])




    
![png](output_0_11.png)
    



    
![png](output_0_12.png)
    

